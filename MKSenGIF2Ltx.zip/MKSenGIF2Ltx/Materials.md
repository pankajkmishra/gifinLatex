
## Course Related Materials
http://ciml.info/dl/v0_8/ciml-v0_8-all.pdf
https://jakevdp.github.io/PythonDataScienceHandbook/
https://towardsdatascience.com/top-5-machine-learning-libraries-in-python-e36e3e0e02af
https://www.cs.ubc.ca/~murphyk/MLbook/


https://d2l.ai/d2l-en.pdf    Dive into Deep learning


http://incompleteideas.net/book/RLbook2020.pdf   Reinforced Learning Book
https://ocw.mit.edu/courses/aeronautics-and-astronautics/16-323-principles-of-optimal-control-spring-2008/lecture-notes/
