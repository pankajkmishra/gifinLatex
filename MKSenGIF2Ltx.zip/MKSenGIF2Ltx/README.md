# Introduction-to-Machine-Learning-for-Geoscienses
Materials related to course GEO371T/391 Fall 2020
